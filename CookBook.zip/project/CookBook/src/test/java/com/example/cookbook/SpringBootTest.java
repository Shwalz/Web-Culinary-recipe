package com.example.cookbook;

public @interface SpringBootTest {
}
