package com.example.cookbook.validation;

public interface RegistrationValidation {}
