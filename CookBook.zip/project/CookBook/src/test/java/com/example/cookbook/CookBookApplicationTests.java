package com.example.cookbook;

import org.junit.jupiter.api.Test;


@com.example.cookbook.SpringBootTest
class CookBookApplicationTests {

    @Test
    void contextLoads() {
    }

}
